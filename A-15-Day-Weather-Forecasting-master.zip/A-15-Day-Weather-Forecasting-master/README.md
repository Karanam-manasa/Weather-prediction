A weather application built using Python & Flask.
